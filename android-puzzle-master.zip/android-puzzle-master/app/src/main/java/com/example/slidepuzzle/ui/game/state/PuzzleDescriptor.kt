package com.example.slidepuzzle.ui.game.state

import android.graphics.Bitmap

data class PuzzleDescriptor(val index: Int, val bitmap: Bitmap)