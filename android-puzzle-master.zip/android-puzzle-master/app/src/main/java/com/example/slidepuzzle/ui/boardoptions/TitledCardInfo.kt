package com.example.slidepuzzle.ui.boardoptions

import android.graphics.Bitmap

data class TitledCardInfo(val image: Bitmap, val title: String)